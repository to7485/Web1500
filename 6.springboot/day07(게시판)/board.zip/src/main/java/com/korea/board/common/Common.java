package com.korea.board.common;

public class Common {
	//객체 관리를 편하게 하기 위한 클래스

	//일반게시판과 공지사항에서
	//한 페이지당 보여줘야 하는 갯수가 다른경우에 다음과 같이 
	//게시판별로 상수화 시켜놓으면 관리하기 편해진다.

	//일반게시판용 상수
	public static class Board{
		
		//한 페이지당 보여줄 게시물 수
		public final static int BLOCKLIST = 10;

		//한 화면에 보여지는 페이지 메뉴 수
		//<- 1 2 3 4 5 ->
		public final static int BLOCKPAGE = 5;
	}

	//댓글의 페이징 처리를 위한 LIST
	public static class Comment{
		//한 페이지당 보여줄 게시물 수
		public final static int BLOCKLIST = 5;

		//한 화면에 보여지는 페이지 메뉴 수
		//<- 1 2 3 4 5 ->
		public final static int BLOCKPAGE = 5;
	}
}
