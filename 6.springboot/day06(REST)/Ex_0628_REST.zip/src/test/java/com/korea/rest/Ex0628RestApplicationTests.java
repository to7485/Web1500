package com.korea.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex0628RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
