package context;

import org.apache.ibatis.session.SqlSession;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import dao.SawonDAO;



@Configuration
public class Context_3_dao {
	
	SqlSession sqlSession;
	
	public Context_3_dao(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Bean
	public SawonDAO sawon_dao() {
		return new SawonDAO(sqlSession);
	}

}
