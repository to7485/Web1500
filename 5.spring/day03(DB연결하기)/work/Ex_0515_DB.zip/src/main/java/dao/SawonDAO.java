package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.SawonVO;

public class SawonDAO {

	SqlSession sqlSession;
	
	public SawonDAO(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	//사원테이블 조회
	public List<SawonVO> selectList(){
		List<SawonVO> list = sqlSession.selectList("s.sawon_list");
		return list;
	}
}
