package vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SawonVO {

	private int sabun,deptno,sapay;
	private String saname;
}
