package vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VisitVO {

	private int idx;
	private String name, content, pwd, ip, regdate;
}
