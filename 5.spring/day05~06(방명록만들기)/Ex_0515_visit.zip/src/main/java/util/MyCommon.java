package util;

public class MyCommon {

	public static String VIEW_PATH = "/WEB-INF/views/visit/";
}
