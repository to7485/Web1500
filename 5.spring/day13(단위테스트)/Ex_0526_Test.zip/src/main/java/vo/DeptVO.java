package vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeptVO {

   private int deptno;
   private String dname,loc;
}
